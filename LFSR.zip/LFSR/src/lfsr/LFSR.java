/*
Joori Eihab 2310656 section CY2
 */
package lfsr;
import java.util.*;

public class LFSR {
        
    // ---------  Parameters  --------
    private static final int LENGTH = 7; //length of the polynomial , LFSR have 7FF(s6-s0
    private static final String POLYNOMIAL = "x^7 + x^4 + x^2 + 1"; //our polynomial
    private static final String FeedbackPOLYNOMIAL = "x^7 = x^4 + x^2 + 1"; //our polynomial
    private static final int[] TAPS = {2, 4, 6}; // S4, S2, S0 positions of XOR
    private static final int[] INITIAL_SEED = {1, 0, 0, 0, 0, 0, 0}; //initial seed
    
    public static void main(String[] args) throws InvalidSeedException, InvalidTapException {
       
            // Step 1: Check if our parameters are valid before running with try-catch
            checkValidParameter();
            
            //Separate logic from I/O , Step 2: Run the LFSR algorithm and get results
            LFSRResult result = runLFSR();
            
            // Step 3: Show the results to the user
            displayResults(result);
    }
    
    /**
     *            Implements LFSR algorithm
     *   This is the core function that runs the Linear Feedback Shift Register:
     */
    private static LFSRResult runLFSR()  {
        
            // create a copy of the initial seed so we don't modify the original one
            int[] register = INITIAL_SEED.clone();
            
            //to store the output sequence (bits that come out)
            StringBuilder output = new StringBuilder();
            
            int period = 0;// How many steps until repetition
            int maxPeriod = (int)Math.pow(2, LENGTH) - 1; //2^7 - 1 = 127
            
            // to display header informations
            System.out.println("LFSR Analysis Polynomial: " + POLYNOMIAL);
            System.out.println("Our feedback Polynomial: " + FeedbackPOLYNOMIAL);
            System.out.println("Max possible period: " + maxPeriod);
            System.out.println("\nClk    S6 S5 S4 S3 S2 S1 S0    Output");
            System.out.println("------------------------------------");
            
            //// Show initial state (step 0) Clk 0
            System.out.printf("0      %s    %n", arrayToString(register));
            
            // Main LFSR loop, run to 128 cycles (more than max possible)
            for (int clock = 1; clock <= 128; clock++) {
                
                // register[TAPS[0]] = S4, register[TAPS[1]] = S2, register[TAPS[2]] = S0
                int feedback = register[TAPS[0]] ^ register[TAPS[1]] ^ register[TAPS[2]];//XOR the tapped bits together
                
                // The output bit is the rightmost bit (S0) before we shift
                int outputBit = register[6];
                output.append(outputBit);// Add to our output sequence
                
                // // SHIFT operation:
                int[] newRegister = new int[LENGTH];// new empty register
                
                newRegister[0] = feedback;// Put feedback bit(result of XOR) in leftmost position (S6)
                
                
                // Copy all bits from old register, shifting them right by one position
                // register[0] goes to newRegister[1], register[1] to newRegister[2], and so on..
                System.arraycopy(register, 0, newRegister, 1, LENGTH - 1);
                
                // Update our register to the new state
                register = newRegister;
                
                // Display the current state
                System.out.printf("%-2d     %s    %d%n", clock, arrayToString(register), outputBit);
                
                // Period detection ,check if we've returned to the initial state
                if (arrayEquals(register, INITIAL_SEED)) {
                    period = clock;// found the period length
                    System.out.println("**** Period: " + period + " ****");
                    
                }
                 
            }
            // Return all our results packaged together
            return new LFSRResult(period, output.toString(), maxPeriod);
            
    }
    /**
     * This function checks if our configurations are valid before running
     */
    private static void checkValidParameter() throws InvalidSeedException, InvalidTapException {
        try {
            // Validate seed length must be exactly 7 bits
            if (INITIAL_SEED.length != LENGTH) {
                throw new InvalidSeedException("Seed length must be " + LENGTH);
            }
            
            // Validate seed is not all zeros , because all-zero state would cause problems
            boolean allZero = true;
            for (int bit : INITIAL_SEED) {
                if (bit != 0) {
                    allZero = false; // Found a 1, so not all zeros
                    break;
                }
            }
            if (allZero) {
                throw new InvalidSeedException("Seed cannot be all zeros");
            }
            
            // Validate tap array not empty , need at least one tap
            if (TAPS.length == 0) {
                throw new InvalidTapException("Taps array cannot be empty");
            }
            
            System.out.println(" All parameters validated successfully ✅");
            
        }
        catch (InvalidSeedException | InvalidTapException e) {
            throw e; }// Re-throw specific exceptions to main method
         catch (Exception e) {
            throw new InvalidSeedException("Unexpected error during parameter validation: " + e.getMessage());
        }
    }
    /**
     *            Display results with analysis
     *            Shows the final results to the user
     */
    private static void displayResults(LFSRResult result) {

            System.out.println("\n**** ANALYSIS RESULTS ****");
            System.out.println("Period: " + result.period);
            System.out.println("Max possible: " + result.maxPeriod);
            System.out.println("Output length: " + result.output.length());
            
            
            //Check if we achieved maximum period (in our case no)
            if (result.period == result.maxPeriod) {
                System.out.println("Maximum period achieved ✅");
            } 
            else {
                System.out.println("Maximum period not achieved ❌");
                System.out.println("Reason: Polynomial is reducible and not primitive");
            }
            
            // to show the full sequence of bits
            System.out.println("Full output sequence: " + result.output);
            
            assessRandomness(result.output); // method to asses the rendomness
    }
    
/*
 *         Randomness assessment : Check the balance 
 */
private static void assessRandomness(String sequence) {
    System.out.println("\n**** Simple Randomness check for LFSR****");
    
    int ones = 0;  // to count 1s 
    for (char bit : sequence.toCharArray()) {
        if (bit == '1') ones++;  // if the bit equals 1 , plass the ones
    }
    int zeros = sequence.length() - ones; // to count 0s
    
    
    // to calculate percentage :
    double onesPercent = (ones * 100.0) / sequence.length(); 
    double zerosPercent = (zeros * 100.0) / sequence.length();
    
    //       for printing
    System.out.println("BALANCE TEST:");
    System.out.println("   • 1s: " + ones + " (" + String.format("%.1f", onesPercent) + "%)");
    System.out.println("   • 0s: " + zeros + " (" + String.format("%.1f", zerosPercent) + "%)");

    
    //  if ratio is between 40-60%, it's good 
    if (ones >= sequence.length()*0.4 && ones <= sequence.length()*0.6) {  // between 40-60%
        System.out.println("   ✅ Good balance (close to 50/50)");
    } else {
        System.out.println("   ❌ Poor balance");
    }
    
    // to call the pattern test:
    performPatternTest(sequence);
}

  /* PATTERN TEST with sliding window of size 2n (14 bits)
 *   Add this method right after assessRandomness */
private static void performPatternTest(String sequence) {
    int n = LENGTH; // n = 7
    int windowSize = 2 * n; // 2n = 14 bits
    
    System.out.println("\nPATTERN TEST (sliding window: " + windowSize + " bits = 2 × " + n + "):");
    
    // Check if sequence is long enough
    if (sequence.length() < windowSize) {
        System.out.println("   • Sequence too short for " + windowSize + "-bit windows");
        return;
    }
    
    Set<String> uniquePatterns = new HashSet<>();
    int totalWindows = 0;
    
    // Slide the 14-bit window through the sequence
    for (int start = 0; start <= sequence.length() - windowSize; start++) {
        String window = sequence.substring(start, start + windowSize);
        uniquePatterns.add(window);
        totalWindows++;
    }
    System.out.println("   • Total sliding windows: " + totalWindows);
    System.out.println("   • Unique " + windowSize + "-bit patterns: " + uniquePatterns.size());
    
    // Simple assessment
    double diversity = (uniquePatterns.size() * 100.0) / totalWindows;
    if (diversity > 50) {
        System.out.println("   ✅ Good pattern diversity (" + String.format("%.1f", diversity) + "%)");
    } else {
        System.out.println("   ❌ Limited pattern diversity (" + String.format("%.1f", diversity) + "%)");
    }
    // Show a few sample patterns
    System.out.println("   • Sample patterns:");
    int count = 0;
    for (String pattern : uniquePatterns) {
        if (count < 2) { // Show only 2 samples
            System.out.println("     - " + pattern);
            count++;
        } else {
            break;
        }
    }
}
    // -------- In this section I uesed methods to help me --------
    
    /*Convert an array of bits to a string for displaying
     * for example: [1,0,0,0,0,0,0] = "1 0 0 0 0 0 0" */
    private static String arrayToString(int[] arr) {
        try {
            StringBuilder sb = new StringBuilder();
            for (int value : arr) {
                sb.append(value).append(" ");
            }
            return sb.toString().trim(); //trim to remove spaces
        } catch (Exception e) {
            return "Error converting array to string";
        }
    }
    
    /*
     * Compare two arrays for equality
     * it returns true if both arrays have same length and same values in same index*/
    private static boolean arrayEquals(int[] a, int[] b) {
        try {
            if (a.length != b.length) return false;
            for (int i = 0; i < a.length; i++) {
                if (a[i] != b[i]) return false;
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }
    // -------- CUSTOM EXCEPTION CLASSES --------
    // These help us to handle different types of errors specifically
    
    static class InvalidSeedException extends Exception {
        public InvalidSeedException(String message) { super(message); }
    }
    
    static class InvalidTapException extends Exception {
        public InvalidTapException(String message) { super(message); }
    }
    
    /**
     *                     Result container class
     *           A simple class to package all our results together
     */
    static class LFSRResult {
        int period;   // How many steps until repetition
        String output; // sequence of bits generated
        int maxPeriod; // maximum period from (2^n - 1)
        
        LFSRResult(int period, String output, int maxPeriod) {
            this.period = period;
            this.output = output;
            this.maxPeriod = maxPeriod;
        }
}
    
}
